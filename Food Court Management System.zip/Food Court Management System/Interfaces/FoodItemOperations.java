package Interfaces; 
import java.lang.*;
import Classes.*;

public interface FoodItemOperations {
    
    public void insertFoodItem(FoodItem f);
    public void removeFoodItem(FoodItem f);
    
    FoodItem getFoodItem(String fid);
    
    public void showAlltFoodItems();
    
       
}
