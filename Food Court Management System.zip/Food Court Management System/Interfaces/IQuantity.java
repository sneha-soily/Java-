package Interfaces;
import Classes.*;


public interface IQuantity
{
	void addQuantity(int amount);
	void sellQuantity(int amount);
	void showInfo();
}