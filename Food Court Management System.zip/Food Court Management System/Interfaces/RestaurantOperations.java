package Interfaces;
import Classes.*;

public interface RestaurantOperations {
    
    public void insertRestaurant(Restaurant r);
    public void removeRestaurant(Restaurant r);
    
    Restaurant getRestaurant(String rid);
    
    public void showAlltRestaurants();
    
}
