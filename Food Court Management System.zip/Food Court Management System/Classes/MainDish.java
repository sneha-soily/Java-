package Classes;
import java.lang.*;


public class MainDish extends FoodItem{
    
    
    private String category;
    
    public void setCategory(String category)
    {
        this.category=category;
    }
    
    public String getCategory()
    {
        return category;
    }
    

    public void showInfo()
	{
		System.out.println("FoodItem fID: "+fid);
		System.out.println("Price: "+price);
		System.out.println("FoodItem Category: "+category);
		System.out.println();
	}

   
    
}
