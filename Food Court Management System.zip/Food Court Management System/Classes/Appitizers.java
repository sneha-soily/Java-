package Classes;
import Interfaces.*;
import java.lang.*;

public class Appitizers extends FoodItem{
    
    private String size;
    
    public void setSize(String size)
    {
        this.size=size;
    }
    
    public String getSize()
    {
        return size;
    }
    
    public void showInfo()
	{
		System.out.println("FoodItem fID: "+fid);
		System.out.println("Price: "+price);
		System.out.println("Food Size: "+size);
		System.out.println();
	}
    
    
}
