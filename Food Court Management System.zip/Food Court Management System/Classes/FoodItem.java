package Classes;

import java.lang.*;
import Interfaces.*;

public  class FoodItem implements IQuantity{
    
    public String fid;
    public String name;
    public int availableQuantity;
    public double price;
    
    public FoodItem()
    {
        
    }
    
    public FoodItem(String fid, String name, int availableQuantity, double price)
    {
        this.fid=fid;
        this.name=name;
        this.availableQuantity=availableQuantity;
        this.price=price;          
    }
    
    public void setFid(String fid)
    {
        this.fid=fid;
    }
    
    public void setName(String name)
    {
        this.name=name;
    }
    
    public void setAvailableQuantity(int availableQuantity)
    {
        this.availableQuantity=availableQuantity;
    }
    
    public void setPrice(double price)
    {
        this.price=price;
    }
     
    public String getFid()
    {
        return fid;
    }
    
    public String getName()
    {
        return name;
    }
    
    public int getAvailableQuantity()
    {
        return availableQuantity;
    }
    
    public double getprice()
    {
        return price;
    }
    

    
    public void addQuantity(int amount)
	{
		if(amount>0)
		{
			System.out.println("Previous price: "+ price);
			System.out.println("Add Quantity: "+ amount);
			price += amount;
			System.out.println("Current price: "+ price);
		}
		else
		{
			System.out.println("Can Not Add Quantity");
		}
	}
	public void sellQuantity(int amount)
	{
		if(amount>0 && amount<=price)
		{
			System.out.println("Previous price:	"+ price);
			System.out.println("Sell Quantity:	"+ amount);
			price -= amount;
			System.out.println("Current price:	"+ price);
		}
		else
		{
			System.out.println("Error Sell Quantity. Try again.");
		}
	}


    public void showInfo()/////// Please Fill this
    {

    }


}
