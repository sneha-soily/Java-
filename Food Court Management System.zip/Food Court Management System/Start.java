import java.util.Scanner;
import Classes.*;
import Interfaces.*;

public class Start {


	public static void main(String[] args) {


		Scanner input = new Scanner(System.in);
		String Username;
		String Password;

		Password = "1234";
		Username = "xyz";

		Scanner input1 = new Scanner(System.in);
		System.out.println("");
		System.out.println("-----------------------FOOD COURT MANAGEMENT SYSTEM----------------------------");
		System.out.print("Enter Username : ");
		String username = input1.next();
		System.out.println("************************************");

		Scanner input2 = new Scanner(System.in);
		System.out.print("Enter Password : ");
		String password = input2.next();
		System.out.println("************************************");

		if (username.equals(Username) && password.equals(Password)) {
			System.out.println("#########################################");
			System.out.println("#       Access Granted! Welcome!        #");
			System.out.println("#########################################");
		    System.out.println();
			
		
		


		 FoodCourt fc = new FoodCourt();

			
			System.out.println("*****What do you want to do?*****");
			System.out.println("1. Employee Management");
			System.out.println("2. Restaurant Management");
			System.out.println("3. Restaurant FoodItem Management");
			System.out.println("4. FoodItem Quantity Add-Sell");
			System.out.println("5. Exit");
			
			System.out.print("Your Option: ");
			int option = input.nextInt();
			
			
			
			
			

			switch (option) {
				case 1:
					System.out.println("-----------------------------------------");
					System.out.println("| You have choosen Employee Management  |");
					System.out.println("-----------------------------------------");

					System.out.println("*****What do you want to do?*****");
					System.out.println("1. Insert New Employee");
					System.out.println("2. Remove Existing Employee");
					System.out.println("3. Search an Employee");
					System.out.println("4. Show All Employees");
					System.out.println("5. Go Back");

					System.out.print("Your Option: ");
					int c1 = input.nextInt();

					switch (c1) {
						case 1:
							System.out.println("-----------------------------------------");
							System.out.println("*****Insert A New Employee*****");

							Employee e = new Employee();
							
						
							System.out.print("Enter Employee ID: ");
							String empId1 = input.next();
							e.setEmpId(empId1);
							
							System.out.print("Enter Employee Name: ");
							String name1 = input.next();
							e.setName(name1);
							
                           try{
							System.out.print("Enter Employee Salary: ");
							double salary1 = input.nextDouble();
							e.setSalary(salary1);
						   
						   fc.insertEmployee(e);
						   }
						   catch (Exception e1){
							   System.out.println("");
							   System.out.println("*****Salary should be a double value*****");
							   System.out.println("");
						   }

							System.out.println("-----------------------------------------");
							break;

						case 2:
							System.out.println("-----------------------------------------");
							System.out.println("*****Remove Existing Employee*****");

							System.out.print("Enter Employee ID: ");
							String empId2 = input.next();

							fc.removeEmployee(fc.getEmployee(empId2));

							System.out.println("-----------------------------------------");
							break;


						case 3:
							System.out.println("-----------------------------------------");
							System.out.println("*****Search an Employee*****");

							System.out.print("Enter Employee ID: ");
							String empId3 = input.next();

							Employee e3 = fc.getEmployee(empId3);

							if (e3 != null) {
								System.out.println("Employee ID is: " + e3.getEmpId());
								System.out.println("Employee Name is: " + e3.getName());
								System.out.println("Employee Salary is: " + e3.getSalary());
							} else {
								System.out.println("*****Employee Does Not Exists*****");
							}

							System.out.println("-----------------------------------------");
							break;

						case 4:
							System.out.println("-----------------------------------------");
							System.out.println("*****Show All Employees*****");

							fc.showAllEmployees();

							System.out.println("-----------------------------------------");
							break;

						case 5:
							System.out.println("-----------------------------------------");
							System.out.println("|              Going Back               |");
							System.out.println("-----------------------------------------");
							break;

						default:

							System.out.println("-----------------------------------------");
							System.out.println("|                Invalid                |");
							System.out.println("-----------------------------------------");
							break;
					}

					break;

				case 2:


					System.out.println("-------------------------------------------");
					System.out.println("|  You have choosen Restaurant Management |");
					System.out.println("-------------------------------------------");

					System.out.println("*****What do you want to do?*****");
					System.out.println("1. Insert New Restaurant");
					System.out.println("2. Remove Existing Restaurant");
					System.out.println("3. Search a Restaurant");
					System.out.println("4. Show All Restaurant");
					System.out.println("5. Go Back");

					System.out.print("Your Option: ");
					int c2 = input.nextInt();

					switch (c2) {
						case 1:
							System.out.println("-----------------------------------------");
							System.out.println("*****Insert New Restaurant*****");

							Restaurant res1 = new Restaurant();

							System.out.print("Enter Restaurant ID: ");
							String rid1 = input.next();
							res1.setRid(rid1);
							String name1;
							System.out.print("Enter Restaurant Name: ");
							

							fc.insertRestaurant(res1);

							System.out.println("-----------------------------------------");
							break;

						case 2:
							System.out.println("-----------------------------------------");
							System.out.println("*****Remove Existing Restaurant*****");

							System.out.print("Enter Restaurant ID: ");
							String rid2 = input.next();


							Restaurant res2 = fc.getRestaurant(rid2);
							fc.removeRestaurant(res2);

							System.out.println("-----------------------------------------");
							break;


						case 3:
							System.out.println("-----------------------------------------");
							System.out.println("*****Search a Restaurant*****");

							System.out.print("Enter Restaurant ID: ");
							String rid3 = input.next();

							Restaurant res3 = fc.getRestaurant(rid3);

							if (res3 != null) {
								System.out.println("Restaurant ID: " + res3.getRid());
								System.out.println("Restaurant Name: " + res3.getName());
								res3.showAllRestaurants();
							} else {
								System.out.println("*****Restaurant Does not Exists*****");
							}

							System.out.println("-----------------------------------------");
							break;

						case 4:
							System.out.println("-----------------------------------------");
							System.out.println("*****Show All Restaurant*****");

							fc.showAllRestaurants();

							System.out.println("-----------------------------------------");
							break;

						case 5:
							System.out.println("-----------------------------------------");
							System.out.println("|             Going Back                |");
							System.out.println("-----------------------------------------");
							break;

						default:

							System.out.println("-----------------------------------------");
							System.out.println("|                Invalid                |");
							System.out.println("-----------------------------------------");
							break;
					}


					break;

				case 3:

					System.out.println("-------------------------------------------------------");
					System.out.println("|   You have choosen Restaurant FoodItem Management   |");
					System.out.println("-------------------------------------------------------");

					System.out.println("*****What do you want to do?*****");
					System.out.println("1. Insert New FoodItem");
					System.out.println("2. Remove Existing FoodItem");
					System.out.println("3. Search a FoodItem");
					System.out.println("4. Show All FoodItem");
					System.out.println("5. Go Back");

					System.out.print("Your Option: ");
					int c3 = input.nextInt();

					switch (c3) {
						case 1:
							System.out.println("-----------------------------------------");
							System.out.println("*****Insert New FoodItem*****");
							System.out.println("");
							System.out.println("     Which Type of FoodItem do you want?");
							System.out.println("");
							System.out.println("1. Main Dish FoodItem");
							System.out.println("2. Appitizers FoodItem");
							System.out.println("3. Go Back");

							System.out.print("Your Type: ");
							int type = input.nextInt();

							FoodItem f = null;

							if (type == 1) {
								System.out.print("Enter FoodItem ID : ");
								String fid1 = input.next();
								try{
								System.out.print("Enter FoodItem Price : ");
								double price1 = input.nextDouble();
								System.out.print("Enter category : ");
								String category1 = input.next();

								MainDish md = new MainDish();
								md.setFid(fid1);
								md.setPrice(price1);
								md.setCategory(category1);

								f = md;
								}
								catch (Exception e2){
								System.out.println("*****Price should be a double value*****");
								}

							} else if (type == 2) {
								System.out.print("Enter FoodItem  ID : ");
								String fid1 = input.next();
								try{
								System.out.print("Enter FoodItem  Price : ");
								double price1 = input.nextDouble();
								System.out.print("Enter Appitizers Name : ");
								String a1 = input.next();

								Appitizers a = new Appitizers();
								a.setFid(fid1);
								a.setPrice(price1);
								a.setSize(a1);

								f = a;
								}
								catch (Exception e3){
								System.out.println("*****Price should be a double value*****");
								}
							} else if (type == 3) {
								System.out.println("     Going Back ...");
							} else {
								System.out.println("*****Invalid Type*****");
							}

							if (f != null) {
								System.out.print("Enter Restaurant ID: ");
								String rid1 = input.next();

								fc.getRestaurant(rid1).insertFoodItem(f);
							}

							System.out.println("-----------------------------------------");
							break;

						case 2:
							System.out.println("-----------------------------------------");
							System.out.println("*****Remove Existing FoodItem*****");

							System.out.print("Enter Restaurant ID: ");
							String rid2 = input.next();
							System.out.print("Enter FoodItem ID: ");
							String fid2 = input.next();

							fc.getRestaurant(rid2).removeFoodItem(fc.getRestaurant(rid2).getFoodItem(fid2));


							System.out.println("-----------------------------------------");
							break;


						case 3:
							System.out.println("-----------------------------------------");
							System.out.println("*****Search a FoodItem*****");

							System.out.print("Enter Restaurant ID: ");
							String rid3 = input.next();
							System.out.print("Enter FoodItem ID: ");
							String foodItem = input.next();

							fc.getRestaurant(rid3).getFoodItem(foodItem);

							FoodItem f3 = new FoodItem();
							if (f3 != null) {


								f3.showInfo();
							}

							System.out.println("-----------------------------------------");
							break;

						case 4:
							System.out.println("-----------------------------------------");
							System.out.println("*****Show All FoodItem*****");

							System.out.print("Enter Restaurant ID: ");
							String rid4 = input.next();

							fc.getRestaurant(rid4).showAlltFoodItems();

							System.out.println("-----------------------------------------");
							break;

						case 5:
							System.out.println("-----------------------------------------");
							System.out.println("|            Going Back                 |");
							System.out.println("-----------------------------------------");
							break;

						default:

							System.out.println("-----------------------------------------");
							System.out.println("|              Invalid                  |");
							System.out.println("-----------------------------------------");
							break;
					}


					break;

				case 4:

					System.out.println("----------------------------------------------------");
					System.out.println("|    You have choosen FoodItems Quantity Add-Sell  |");
					System.out.println("----------------------------------------------------");

					System.out.println("*****What do you want to do?*****");
					System.out.println("");
					System.out.println("1. Add FoodItem");
					System.out.println("2. Sell FoodItem");
					System.out.println("3. Show Add Sell History");
					System.out.println("4. Go Back");

					System.out.print("Your Option: ");
					int c4 = input.nextInt();

					switch (c4) {
						case 1:
						try {
                           
							System.out.println("-----------------------------------------");
							System.out.println("*****Add FoodItem*****");

							System.out.print("Enter Restaurant Id: ");
							String rid1 = input.next();
							System.out.print("Enter FoodItem ID: ");
							String fid1 = input.next();
							System.out.print("Enter Amount: ");
							int amount1 = input.nextInt();
						}
					    catch (Exception e4){
							System.out.println("");
							System.out.println("*****Amount should be an integer value*****");
							System.out.println("");
						} 
						

							System.out.println("-----------------------------------------");
							break;
						

						case 2:

							System.out.println("-----------------------------------------");
							System.out.println("*****Sell FoodItem*****");

							System.out.print("Enter Restaurant Id: ");
							String rid2 = input.next();
							System.out.print("Enter FoodItem ID: ");
							String fid2 = input.next();
							try{
							System.out.print("Enter Amount: ");
							int amount2 = input.nextInt();
							


							if (amount2 > 0 && amount2 <= fc.getRestaurant(rid2).getFoodItem(fid2).getAvailableQuantity()) {


								Restaurant rr = fc.getRestaurant(rid2);
								FoodItem ff = rr.getFoodItem(fid2);
								ff.sellQuantity(amount2);


							}
							}
							catch(Exception e5){
								System.out.println("");
							    System.out.println("*****Amount should be an integer value*****");
							    System.out.println("");
							}

							System.out.println("-----------------------------------------");
							break;


						case 3:

							System.out.println("-----------------------------------------");
							System.out.println("|          Show Add Sell History        |");
							System.out.println("-----------------------------------------");
							break;

						case 4:

							System.out.println("-----------------------------------------");
							System.out.println("|             Going back....            |");
							System.out.println("-----------------------------------------");
							break;

						default:

							System.out.println("-----------------------------------------");
							System.out.println("|               Invalid                 |");
							System.out.println("-----------------------------------------");
							break;
					}

					break;

				case 5:

					System.out.println("*****You have choosen to exit*****");
					System.exit(0);
					break;

				default:

					System.out.println("*****Invalid Option*****");
					break;
			}
			
			} else if (username.equals(Username)) {
			System.out.println("*****Invalid Password!*****");
			System.out.println("");
			System.out.println("     YOU CAN NOT ACCESS THIS SYSTEM");
		} else if (password.equals(Password)) {
			System.out.println("*****Invalid Username!*****");
			System.out.println("");
			System.out.println("     YOU CAN NOT ACCESS THIS SYSTEM");
		} else {
			System.out.println("*****Invalid Username & Password!*****");
			System.out.println("");
			System.out.println("     YOU CAN NOT ACCESS THIS SYSTEM");
		}
			
		
			
           }


		}






